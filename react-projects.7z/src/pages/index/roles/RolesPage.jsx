import React from 'react'

const RolesPage = () => {
  return (
    <div>RolesPage</div>
  )
}

export default RolesPage
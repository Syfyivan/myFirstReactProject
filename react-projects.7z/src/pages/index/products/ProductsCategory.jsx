import React from 'react'

const ProductsCategory = () => {
  return (
    <div>ProductsCategory</div>
  )
}

export default ProductsCategory
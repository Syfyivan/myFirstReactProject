import React from 'react'

const ProductsList = () => {
  return (
    <div>ProductsList</div>
  )
}

export default ProductsList
import React from 'react'

const LoginPage = () => {
  return (
    <div>LoginPage</div>
  )
}

export default LoginPage
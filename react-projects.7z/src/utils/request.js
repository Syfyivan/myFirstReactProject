import axios from "axios";

const request = axios.create({
    baseURL: 'http://localhost:8080',
    timeout: 5000
})
// // 响应拦截器, 用于处理响应数据
// request.interceptors.request.use(res => res.data)

export default request


